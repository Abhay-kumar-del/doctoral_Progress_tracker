package com.example.SE.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
