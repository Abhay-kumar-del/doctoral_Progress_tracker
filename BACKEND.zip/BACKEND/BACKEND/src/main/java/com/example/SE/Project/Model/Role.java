package com.example.SE.Project.Model;

public enum Role {
    STUDENT,
    COORDINATOR,
    SUPERVISOR
}